package com.phonec.mirrodisply;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

@SuppressLint({"AppCompatCustomView"})
public class COM_BLFOUR_FontText extends TextView {
    public COM_BLFOUR_FontText(Context context) {
        super(context);
        setStyle();
    }

    public COM_BLFOUR_FontText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setStyle();
    }

    public COM_BLFOUR_FontText(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setStyle();
    }

    public void setStyle() {
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "Poppins-Regular.otf"), 1);
    }
}
