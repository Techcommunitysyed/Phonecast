package com.phonec.mirrodisply;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class COM_BLFOUR_GuideActivity extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.com_blfour_activity_guide);
        getWindow().addFlags(1024);
        WebView webView = (WebView) findViewById(R.id.webView);
        webView.setBackgroundColor(0);
        COM_BLFOUR_Utl.SetUIRelative(this, (ImageView) findViewById(R.id.img), 1080, 653);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams((getResources().getDisplayMetrics().widthPixels * 1032) / 1080, (getResources().getDisplayMetrics().heightPixels * 1354) / 1920);
        layoutParams.setMargins(0, (getResources().getDisplayMetrics().heightPixels * 440) / 1920, 0, 0);
        ((LinearLayout) findViewById(R.id.layout_text)).setLayoutParams(layoutParams);
        findViewById(R.id.backy).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("file:///android_asset/guide.html");
    }
}
