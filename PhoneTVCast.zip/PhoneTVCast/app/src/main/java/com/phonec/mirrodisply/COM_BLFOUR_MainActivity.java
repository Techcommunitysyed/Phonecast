package com.phonec.mirrodisply;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class COM_BLFOUR_MainActivity extends Activity {
    ImageView connect1;
    ImageView how;
    ImageView privacy1;
    ImageView rateapp;
    ImageView shareapp;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.com_blfour_activity_main);
        getWindow().addFlags(1024);
        checkWifi();
        connect1 = (ImageView) findViewById(R.id.connect1);
        how = (ImageView) findViewById(R.id.how);
        shareapp = (ImageView) findViewById(R.id.shareapp);
        rateapp = (ImageView) findViewById(R.id.rateapp);
        privacy1 = (ImageView) findViewById(R.id.privacy1);
        COM_BLFOUR_Utl.SetUILinear(this, findViewById(R.id.logo), 1080, 1223);
        COM_BLFOUR_Utl.SetUILinear(this, connect1, 275, 330);
        COM_BLFOUR_Utl.SetUILinear(this, how, 275, 330);
        COM_BLFOUR_Utl.SetUILinear(this, shareapp, 125, 130);
        COM_BLFOUR_Utl.SetUILinear(this, rateapp, 125, 130);
        COM_BLFOUR_Utl.SetUILinear(this, privacy1, 125, 130);
        connect1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (checkWifi()) {
                    openWiFiDisplay();
                }
            }
        });
        how.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(COM_BLFOUR_MainActivity.this, COM_BLFOUR_GuideActivity.class));
            }
        });
        shareapp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", "https://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(intent, "Share using"));
            }
        });
        rateapp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                COM_BLFOUR_MainActivity cOM_BLFOUR_MainActivity = COM_BLFOUR_MainActivity.this;
                cOM_BLFOUR_MainActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
            }
        });
        privacy1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(COM_BLFOUR_MainActivity.this, COM_BLFOUR_PolicyAct.class));
            }
        });
    }

    @SuppressLint("WrongConstant")
    public void openWiFiDisplay() {
        try {
            startActivity(new Intent("android.settings.WIFI_DISPLAY_SETTINGS"));
        } catch (Exception e) {
            e.printStackTrace();
            try {
                startActivity(new Intent("com.samsung.wfd.LAUNCH_WFD_PICKER_DLG"));
            } catch (Exception e2) {
                e2.printStackTrace();
                try {
                    startActivity(new Intent("android.settings.CAST_SETTINGS"));
                } catch (Exception e3) {
                    e3.printStackTrace();
                    Toast.makeText(this, "Your device do not supported", 0).show();
                }
            }
        }
    }

    /* access modifiers changed from: private */
    @SuppressLint("ResourceType")
    public boolean checkWifi() {
        @SuppressLint("WrongConstant") final WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService("wifi");
        if (wifiManager.isWifiEnabled()) {
            return true;
        }
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(16843605, typedValue, true);
        new AlertDialog.Builder(this).setTitle("WARNING").setCancelable(false).setMessage("App can not use if without WIFI, please it turn on.").setIcon(typedValue.resourceId).setPositiveButton("Turn on wifi", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                wifiManager.setWifiEnabled(true);
                dialogInterface.dismiss();
            }
        }).setNegativeButton(getString(17039360), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }).show();
        return false;
    }

    public void onBackPressed() {
        @SuppressLint("ResourceType") final Dialog dialog = new Dialog(this, 16973831);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.com_blfour_dialog_exit);
        ImageView imageView = (ImageView) dialog.findViewById(R.id.yes);
        ImageView imageView2 = (ImageView) dialog.findViewById(R.id.no);
        COM_BLFOUR_Utl.SetUIRelative(this, imageView2, 310, 160);
        COM_BLFOUR_Utl.SetUIRelative(this, imageView, 310, 160);
        COM_BLFOUR_Utl.SetUILinear(this, (LinearLayout) dialog.findViewById(R.id.popup), 980, 659);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finishAffinity();
                dialog.dismiss();
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
