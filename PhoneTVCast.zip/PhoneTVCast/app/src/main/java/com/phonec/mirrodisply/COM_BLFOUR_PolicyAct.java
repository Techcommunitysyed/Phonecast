package com.phonec.mirrodisply;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class COM_BLFOUR_PolicyAct extends Activity {
    ImageView back;
    private Context mContext;
    /* access modifiers changed from: private */
    public ProgressBar progress_bar;
    private WebView webview;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.com_blfour_policy);
        getWindow().addFlags(1024);
        this.back = (ImageView) findViewById(R.id.back);
        TextView textView = (TextView) findViewById(R.id.header);
        this.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                COM_BLFOUR_PolicyAct.this.onBackPressed();
            }
        });
        getWindow().setFlags(16777216, 16777216);
        this.mContext = this;
        ui();
        init();
    }

    private void ui() {
        this.progress_bar = (ProgressBar) findViewById(R.id.progress_bar);
        this.webview = (WebView) findViewById(R.id.wv_privacy_policy);
        WebSettings settings = this.webview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        settings.setCacheMode(2);
        settings.setDomStorageEnabled(true);
        this.webview.setScrollBarStyle(33554432);
        this.webview.setScrollbarFadingEnabled(true);
        if (Build.VERSION.SDK_INT >= 19) {
            this.webview.setLayerType(2, (Paint) null);
        } else {
            this.webview.setLayerType(1, (Paint) null);
        }
    }

    private void init() {
        this.webview.loadUrl("file:///android_asset/privacy_policy.html");
        this.webview.requestFocus();
        this.progress_bar.setVisibility(0);
        this.webview.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView webView, String str) {
                try {
                    COM_BLFOUR_PolicyAct.this.progress_bar.setVisibility(8);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
