package com.phonec.mirrodisply;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

public class COM_BLFOUR_SplashActivity extends Activity {
    int[] imageArray = {R.drawable.dot1, R.drawable.dot2, R.drawable.dot3, R.drawable.dot4};
    ImageView proimg;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.com_blfour_activity_splash);
        getWindow().addFlags(1024);
        this.proimg = (ImageView) findViewById(R.id.txtlogo);
        COM_BLFOUR_Utl.SetUIRelative(this, this.proimg, 160, 30);
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            int i = 0;

            public void run() {
                COM_BLFOUR_SplashActivity.this.proimg.setImageResource(COM_BLFOUR_SplashActivity.this.imageArray[this.i]);
                this.i++;
                if (this.i > COM_BLFOUR_SplashActivity.this.imageArray.length - 1) {
                    this.i = 0;
                }
                handler.postDelayed(this, 1000);
            }
        }, 1000);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                COM_BLFOUR_SplashActivity.this.startActivity(new Intent(COM_BLFOUR_SplashActivity.this, COM_BLFOUR_MainActivity.class));
            }
        }, 4000);
    }
}
