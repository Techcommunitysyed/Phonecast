package com.phonec.mirrodisply;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class COM_BLFOUR_Utl {
    public static void SetUIRelative(Context context, View view, int i, int i2) {
        view.setLayoutParams(new RelativeLayout.LayoutParams((context.getResources().getDisplayMetrics().widthPixels * i) / 1080, (context.getResources().getDisplayMetrics().heightPixels * i2) / 1920));
    }

    public static void SetUILinear(Context context, View view, int i, int i2) {
        view.setLayoutParams(new LinearLayout.LayoutParams((context.getResources().getDisplayMetrics().widthPixels * i) / 1080, (context.getResources().getDisplayMetrics().heightPixels * i2) / 1920));
    }

    public static void SetUILinearVivo(Context context, View view, int i, int i2) {
        view.setLayoutParams(new LinearLayout.LayoutParams((context.getResources().getDisplayMetrics().widthPixels * i) / 1080, (context.getResources().getDisplayMetrics().widthPixels * i2) / 1080));
    }

    public static void SetUIRelativeVivo(Context context, View view, int i, int i2) {
        view.setLayoutParams(new RelativeLayout.LayoutParams((context.getResources().getDisplayMetrics().widthPixels * i) / 1080, (context.getResources().getDisplayMetrics().widthPixels * i2) / 1080));
    }

    public static void SetUIRelativeTopMargin(Context context, View view, int i, int i2, int i3) {
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((context.getResources().getDisplayMetrics().widthPixels * i) / 1080, (context.getResources().getDisplayMetrics().heightPixels * i2) / 1920);
        layoutParams.topMargin = (context.getResources().getDisplayMetrics().widthPixels * i3) / 1920;
        view.setLayoutParams(layoutParams);
    }
}
